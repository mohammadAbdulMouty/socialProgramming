C:\xampp\htdocs\Sprogramming\projects\20171126090255\about.php<?php
session_start();
echo "Hello ".$_SESSION['name']."How are you";
echo 'mohammad abdul mouty';