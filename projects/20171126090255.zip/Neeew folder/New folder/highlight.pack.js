document.getElementById('hi');
console.log("hi");
var i = "mohammad";
i.slice(" ");
